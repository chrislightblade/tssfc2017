/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Biblioteca;

import java.util.Date;


/**
 *
 * @author tss
 */
public class Cliente extends Persona{
           
    private int codCliente;

    public Cliente(int codCliente, String nominativo, int numtel) {
        super(nominativo, numtel);
        this.codCliente = codCliente;
    }

    public int getCodCliente() {
        return codCliente;
    }    
    
}
